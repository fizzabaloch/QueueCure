studentName= ['sumaiya','hina','fahad']
studentId=['1','2','3']
marks=[[12,23,34,45,56],[21,32,43,54,65],[87,12,34,54,57]]

i=0

while i<3:
    j=0
    sum=0
    while j<5:
        sum+=marks[i][j]
        per=sum/500*100
        j+=1
    
    print('ID' + ' ' + 'NAME' + ' ' + 'MARKS OBTAINED' + ' ' + 'TOTAL MARKS' + ' ' + 'PERCENTAGE')
    print(studentId[i] + ' ' + studentName[i] + ' ' + str(marks[i]) + ' ' + str(sum) + ' ' + str(per))
    i+=1





















 #   roll_number = input("Enter your roll number: ")
# name = input("Enter your name: ")
# number_of_subjects = int(input("Enter number of subjects: "))

# marks = []

# for i in range(number_of_subjects):
#     mark = int(input(f"Enter marks of subject {i + 1}: "))
#     marks.append(mark)

# for i in range(number_of_subjects):
#     print(marks[i])

# obt = int(0)
# for i in range(number_of_subjects):
#     obt += marks[i]

# print("Percentage is ", (obt / (100 * number_of_subjects)) * 100)





