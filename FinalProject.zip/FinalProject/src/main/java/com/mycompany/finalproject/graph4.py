import networkx as nx
import matplotlib.pyplot as plt
g=nx.Graph()

g.add_node(1)
g.add_node(5)
g.add_node(2)
g.add_node(3)
g.add_node(4)
g.add_edge(5,2)
g.add_edge(4,3)
g.add_edge(5,4)
g.add_edge(1,5)
g.add_edge(5,1)
nx.draw(g)
plt.show()




