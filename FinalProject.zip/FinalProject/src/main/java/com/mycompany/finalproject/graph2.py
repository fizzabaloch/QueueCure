import matplotlib.pyplot as plt

x=[1,2,3]
y=[3,4,5]

plt.plot(x,y, label = 'line#1')
plt.plot(x,y, label = 'line#2')

plt.legend()
plt.xlabel('X-axis')
plt.ylabel('Y-axis')

plt.title('line graph')
plt.show()