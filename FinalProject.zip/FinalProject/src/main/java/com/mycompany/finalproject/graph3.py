import matplotlib.pyplot as plt

x=[1,2,3,3,4,5]
y=[3,4,5,6,7,8]

plt.plot(x,y, label = 'line#1')
plt.plot(x,y, label = 'line#2')

plt.ylim(1,9)
plt.xlim(1,9)

plt.legend()

plt.xlabel('X-axis')
plt.ylabel('Y-axis')

plt.title('line graph')

plt.plot(x,y, color='cyan',linestyle='dashed',linewidth=6, marker='o',markerfacecolor='blue',markersize=15)

plt.show()